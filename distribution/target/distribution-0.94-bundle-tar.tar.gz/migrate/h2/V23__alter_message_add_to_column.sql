alter table t_messages add column `_to` varchar(64) DEFAULT NULL;

