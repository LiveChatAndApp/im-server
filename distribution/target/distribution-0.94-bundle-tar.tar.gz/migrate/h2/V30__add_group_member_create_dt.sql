alter table t_group_member add column `_create_dt`  bigint(20) DEFAULT 0;
