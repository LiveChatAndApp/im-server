alter table `t_user_messages` add column `_cont_type` int(11) NOT NULL DEFAULT '0';
