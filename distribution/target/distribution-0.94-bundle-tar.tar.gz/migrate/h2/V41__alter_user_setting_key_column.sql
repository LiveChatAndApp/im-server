alter table `t_user_setting` modify column `_key` varchar(128) NOT NULL;
