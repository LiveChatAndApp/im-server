update t_messages_0 set _dt = date_add(_dt, interval 8 hour);
update t_messages_1 set _dt = date_add(_dt, interval 8 hour);
update t_messages_2 set _dt = date_add(_dt, interval 8 hour);
update t_messages_3 set _dt = date_add(_dt, interval 8 hour);
update t_messages_4 set _dt = date_add(_dt, interval 8 hour);
update t_messages_5 set _dt = date_add(_dt, interval 8 hour);
update t_messages_6 set _dt = date_add(_dt, interval 8 hour);
update t_messages_7 set _dt = date_add(_dt, interval 8 hour);
update t_messages_8 set _dt = date_add(_dt, interval 8 hour);
update t_messages_9 set _dt = date_add(_dt, interval 8 hour);

update t_messages_10 set _dt = date_add(_dt, interval 8 hour);
update t_messages_11 set _dt = date_add(_dt, interval 8 hour);
update t_messages_12 set _dt = date_add(_dt, interval 8 hour);
update t_messages_13 set _dt = date_add(_dt, interval 8 hour);
update t_messages_14 set _dt = date_add(_dt, interval 8 hour);
update t_messages_15 set _dt = date_add(_dt, interval 8 hour);
update t_messages_16 set _dt = date_add(_dt, interval 8 hour);
update t_messages_17 set _dt = date_add(_dt, interval 8 hour);
update t_messages_18 set _dt = date_add(_dt, interval 8 hour);
update t_messages_19 set _dt = date_add(_dt, interval 8 hour);

update t_messages_20 set _dt = date_add(_dt, interval 8 hour);
update t_messages_21 set _dt = date_add(_dt, interval 8 hour);
update t_messages_22 set _dt = date_add(_dt, interval 8 hour);
update t_messages_23 set _dt = date_add(_dt, interval 8 hour);
update t_messages_24 set _dt = date_add(_dt, interval 8 hour);
update t_messages_25 set _dt = date_add(_dt, interval 8 hour);
update t_messages_26 set _dt = date_add(_dt, interval 8 hour);
update t_messages_27 set _dt = date_add(_dt, interval 8 hour);
update t_messages_28 set _dt = date_add(_dt, interval 8 hour);
update t_messages_29 set _dt = date_add(_dt, interval 8 hour);


update t_messages_30 set _dt = date_add(_dt, interval 8 hour);
update t_messages_31 set _dt = date_add(_dt, interval 8 hour);
update t_messages_32 set _dt = date_add(_dt, interval 8 hour);
update t_messages_33 set _dt = date_add(_dt, interval 8 hour);
update t_messages_34 set _dt = date_add(_dt, interval 8 hour);
update t_messages_35 set _dt = date_add(_dt, interval 8 hour);
