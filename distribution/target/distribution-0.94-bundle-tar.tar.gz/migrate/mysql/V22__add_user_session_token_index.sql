alter table `t_user_session` ADD INDEX `session_token_index` ( `_token` );
