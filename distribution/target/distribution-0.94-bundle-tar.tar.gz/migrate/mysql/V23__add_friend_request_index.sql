alter table t_friend_request add index `friend_request_uid_index` (`_friend_uid`);
