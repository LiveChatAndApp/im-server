update t_channel set `_status` = 64 where `_status` = 3;
