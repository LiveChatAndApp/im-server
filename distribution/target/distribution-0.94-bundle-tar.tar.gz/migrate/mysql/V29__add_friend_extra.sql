alter table t_friend add column `_extra` TEXT DEFAULT NULL;
