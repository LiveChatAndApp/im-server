alter table `t_settings` change column `value` `_value` varchar(64) NOT NULL;
alter table `t_settings` change column `desc` `_desc` varchar(64) NOT NULL;
