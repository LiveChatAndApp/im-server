alter table `t_group` modify column `_searchable` int(11) NOT NULL DEFAULT 0;
