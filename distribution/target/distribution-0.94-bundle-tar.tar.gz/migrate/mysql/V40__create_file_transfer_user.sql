
insert into t_user (`_uid`,`_name`,`_display_name`,`_portrait`,`_type`,`_dt`) values ('wfc_file_transfer','wfc_file_transfer','文件传输助手','https://static.wildfirechat.cn/wfc_file_transfer.png',1,1);
insert into t_robot (`_uid`,`_owner`,`_secret`,`_callback`,`_state`,`_dt`) values ('wfc_file_transfer', 'wfc_file_transfer', '', '', 0, 1);
