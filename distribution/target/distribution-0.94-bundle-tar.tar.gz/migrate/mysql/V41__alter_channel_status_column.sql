alter table `t_channel` modify column `_status` int(11) NOT NULL DEFAULT 0;
