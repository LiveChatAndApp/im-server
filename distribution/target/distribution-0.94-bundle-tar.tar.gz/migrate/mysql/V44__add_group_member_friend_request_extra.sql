alter table `t_group_member` add column `_extra` TEXT DEFAULT NULL;
alter table `t_friend_request` add column `_extra` TEXT DEFAULT NULL;
