alter table `t_user_setting` modify column `_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL;
