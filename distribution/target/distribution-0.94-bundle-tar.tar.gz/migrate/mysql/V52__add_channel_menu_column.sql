alter table `t_channel` add column `_menu` BLOB DEFAULT NULL;
